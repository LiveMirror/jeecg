http://127.0.0.1:8080/jeecg-v3-simple/services/user/gets/xml
http://127.0.0.1:8080/jeecg-v3-simple/services/user/getById/xml/4028811e4152ef07014152f0d298003f
http://127.0.0.1:8080/jeecg-v3-simple/services/user/insert/json/yankang/zhangyan/4028811e4152ef07014152f0d1dd0015
http://127.0.0.1:8080/jeecg-v3-simple/services/user/delete/xml/402881e3415ed86001415ed9a85e0001
http://127.0.0.1:8080/jeecg-v3-simple/services/user/update/xml/zhangyan/zhangyan/402881e3415ed86001415edc916c0002