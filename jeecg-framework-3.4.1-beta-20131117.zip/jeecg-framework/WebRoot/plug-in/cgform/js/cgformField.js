var filedTypes = ['check', 'database', 'key', 'page'];
var headerTr = "template_header_";
var bodytr = "add_column_table_template_";
var iframeId = "iframe_";
var fieldData = [];// 字段的数据
var iframeLoadNumber = 0; // 当前加载的Iframe的数量

$(document).ready(iframeLoaded());
$("#iframe_check").load(iframeLoaded());
$("#iframe_database").load(iframeLoaded());
$("#iframe_key").load(iframeLoaded());
$("#iframe_page").load(iframeLoaded());

function iframeLoaded() {
	iframeLoadNumber++;
	if (iframeLoadNumber == 5) {
		$(".datagrid-toolbar").parent().css("width", "auto");
		setTimeout(initData, 500);
	}
}



function initData() {
	addTableHead();
	$.get("cgFormHeadController.do?getColumnList&id=" + $("#id").val(),
			getDataHanlder);
	
}

/**
 * 添加表头
 */
function addTableHead() {
	for (var i = 0; i < filedTypes.length; i++) {
		var tr = $(getIframeDocument(filedTypes[i])).find("#"
				+ headerTr + filedTypes[i] + " tr").clone();
		$("#tab_div_" + filedTypes[i]+"_title").append(tr);
	}
}
// 兼容不同浏览器获取iframe 内容
function getIframeDocument(id){
	if($.browser.mozilla){
		return window.frames["iframe_" + id].contentDocument;
	}else{
		return window.frames["iframe_" + id].document;
	}
}

/**
 * 获取数据的回调
 * 
 * @param {}
 *            data
 */
function getDataHanlder(data) {
	data = eval("(" + data + ")");
	// 兼容之前order最小为0的问题
	var orderMin = data[0].orderNum == 0;
	$.each(data, function(idx, item) {
				for (var i = 0; i < filedTypes.length; i++) {
					initTrData(item, filedTypes[i], orderMin);
				}
			});
	jformTypeChange();
	fixTab();
	
}
/**
 * 添加行数据
 * 
 * @param {}
 *            item 这个数据
 * @param {}
 *            filedType 这一行的类型
 */
function initTrData(item, filedType, orderMin) {
	var tr = $(getIframeDocument(filedType)).find("#" + bodytr
			+ filedType + " tr").clone();
 	var isId = item.fieldName == "id";
	$(':input, select', $(tr)).each(function() {
		var $this = $(this), name = $this.attr('name'), val = $this.val();
		if(isId){setAttrForThis($this);}
		if (name.indexOf("#index#") > 0) {
			var fieldName = name.replace("columns[#index#].", "");
			$this.attr("name", name.replace('#index#', orderMin
									? item.orderNum
									: item.orderNum - 1));
			
			if (item[fieldName] != "Y" && item[fieldName] != "N") {
				$this.val(item[fieldName]);
			} else {
				item[fieldName] == "Y" ? $this.attr("checked", true) : $this
						.attr("checked", false);
			}
		} else if (name != "ck") {
			$this.attr("name", name.replace('_index', orderMin
									? item.orderNum
									: item.orderNum - 1));
			$this.val(name.indexOf("columnsfieldName") != -1
					? item.fieldName
					: item.content);
		} else {
			$this.val(item.id);
		}
	});
	$("#tab_div_" + filedType).append(tr);
}

function setAttrForThis($this){
	if($this.is('select')){
		$this.attr("onfocus","this.defOpt=this.selectedIndex");
		$this.attr("onchange","this.selectedIndex=this.defOpt;");
	}else if($this.is('input')&&$this.attr('type')=='text'){
		$this.attr("readonly","readonly");
	}else if($this.is('input')&&$this.attr('type')=='checkbox'){
		$this.attr("onclick","return false;");
	}
}

/**
 * 添加行
 */
function addColumnBtnClick() {
	for (var i = 0; i < filedTypes.length; i++) {
		addTrToTable(filedTypes[i]);
	}
}
function addTrToTable(filedType) {
	var tr = $(getIframeDocument(filedType)).find("#" + bodytr
			+ filedType + " tr").clone();
	$("#tab_div_" + filedType).append(tr);
	resetTrNum('#tab_div_' + filedType);
}

/**
 * 删除行
 */
function delColumnBtnClick() {
	// 删除字段数据
	if ($("#tab_div_database").find("input[name='ck']:checked").val() != null
			&& $("#add_colunm_table").find("input[name='ck']:checked").val() != "on") {
		$
				.post("cgFormHeadController.do?delField&id="
						+ $("#tab_div_database")
								.find("input[name='ck']:checked").val());
	}
	// 获取当前的check的行数
	var index = $("#tab_div_database").find("input[name='ck']:checked")
			.parent().parent("tr").prevAll().length;
	for (var i = 0; i < filedTypes.length; i++) {
		$("#tab_div_" + filedTypes[i]).find("tr").eq(index).remove();
		resetTrNum("#tab_div_" + filedTypes[i]);
	}

}
/**
 * 重设table的order
 * 
 * @param {}
 *            tableId
 */
function resetTrNum(tableId) {
	$(tableId + " tbody tr").each(function(i) {
		$(':input, select', this).each(function() {
					var $this = $(this), name = $this.attr('name'), val = $this
							.val();
					if (name != null && name.indexOf("#index#") >= 0) {
						$this.attr("name", name.replace('#index#', i));
						if (name.indexOf('orderNum') >= 0) {
							$this.val(getMaxNum());
						}
					} else if (name != null && name.indexOf("_index") >= 0) {
						$this.attr("name", name.replace('_index', i));
					} else if (name != null && name != "ck"
							&& name.indexOf("[") >= 0) {
						$this.attr("name", name.replace(getNowIndex(name), i));
					}
				});
	});
	jformTypeChange();
}
/**
 * 获取最大的 orderNum
 */
function getMaxNum() {
	var maxNum = 0;
	$("input[name*='orderNum']").each(function() {
				maxNum = parseInt($(this).val()) > maxNum
						? $(this).val()
						: maxNum;
			});
	return parseInt(maxNum) + 1;
}

/**
 * 同步fieldName
 */
$(document).on('change', '.fieldNameInput','columnsfieldName',valueChange);

/**
 * 同步content
 */
$(document).on('change', '.contentInput','columnscontent',valueChange);


function valueChange(e){
	var val = $(this).val();
	var index = getNowIndex($(this).attr('name'));
	for (var i = 0; i < filedTypes.length; i++) {
		$("#tab_div_" + filedTypes[i]).find("input[name='"+e.data+
				+ index + "']").val(val);
	}
}

/**
 * 获取当前的索引值
 * 
 * @param {}
 *            name 这个元素的Name
 * @return {}
 */
function getNowIndex(name) {
	var s = name.indexOf("[");
	var e = name.indexOf("]");
	return name.substring(s + 1, e);
}

/**
 * 表类型的改变,附表才可以设置主表
 */
function jformTypeChange(){
	openOrCloseSetKeyOp($("#jformType").val() == 3);
	openOrCloseRelationTypeDisplay($("#jformType").val() == 3);
}
//控制：只有附表才可以选择附表关联类型
function openOrCloseRelationTypeDisplay(boo){
	if(boo){
		$("#relation_type_div").attr("style","display: block;");
	}else{
		$("#relation_type_div").attr("style","display: none;");
	}
}

function openOrCloseSetKeyOp(boo){
	$("#tab_div_key tbody tr").each(function(i) {
		$(':input', this).each(function() {
					var $this = $(this), name = $this.attr('name');
					if (name != null && (name.indexOf("mainTable") >= 0
					||name.indexOf("mainField") >= 0)&&
					name!="columns[0].mainTable"&&name!="columns[0].mainField") {
						boo?$this.removeAttr("readonly"):
							$this.attr("readonly","readonly");
					}
				});
	});
}


/**
 * fix修复
 */
function fixTab(){
	$('#tabs').tabs({
	    onSelect:function(title){
	        if(title=="数据库属性"){fix("database");}
	        else if(title=="页面属性"){fix("page");}
	        else if(title=="校验字典"){fix("check");}
	        else if(title=="外键"){fix("key");}
	        $('#tabs .panel-body').css('width','auto');
	    }
	});
	$('#t_table_database').scroll(function(){
 		 $('#tab_div_database_title').css('margin-left',-($('#t_table_database').scrollLeft()));
	});
	$('#t_table_page').scroll(function(){
 		 $('#tab_div_page_title').css('margin-left',-($('#t_table_page').scrollLeft()));
	});
	$('#t_table_check').scroll(function(){
 		 $('#tab_div_check_title').css('margin-left',-($('#t_table_check').scrollLeft()));
	});
	$('#t_table_key').scroll(function(){
 		 $('#tab_div_key_title').css('margin-left',-($('#t_table_key').scrollLeft()));
	});
}

//利用js让头部与内容对应列宽度一致。
function fix(type){
	for(var i=0;i<=$('#tab_div_'+type+' tr:last').find('td:last').index();i++){
  			$('#tab_div_'+type+'_title th').eq(i).css('width',
  				$('#tab_div_'+type+' tr:last').find('td').eq(i).width());
 	}
 	$('#tab_div_'+type+'_title').css('width',
 	 		$('#tab_div_'+type+' tr:last').width());
}



